USE [CrudProspectos]
GO

/****** Object:  Table [dbo].[Prospectos]    Script Date: 26/01/2023 01:05:02 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO 
   
CREATE TABLE [dbo].[Prospectos](
	[IdProspecto] [int] IDENTITY(1,1) NOT NULL,
	[nombredelProspecto] [varchar](50) NOT NULL,
	[primerApellido] [varchar](30) NOT NULL,
	[segundoApellido] [varchar](30) NULL,
	[calle] [varchar](50) NOT NULL,
	[numero] [int] NOT NULL,
	[colonia] [varchar](50) NOT NULL,
	[codigoPostal] [int] NOT NULL,
	[telefono] [varchar](30) NOT NULL,
	[rfc] [varchar](30) NOT NULL,
	[estatus] [int] NOT NULL,
	[archivoBase64] [varchar](max) NULL,
	[motivoRechazo] [varchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[IdProspecto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Prospectos] ADD  DEFAULT ((1)) FOR [estatus]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'1=Prospecto, 2=En validacion, 3=Aceptado, 4=Cancelado' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Prospectos', @level2type=N'COLUMN',@level2name=N'estatus'
GO


